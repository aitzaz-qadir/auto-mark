import java.util.ArrayList;
public class GenericStack<T>{
    
    private ArrayList<T> stack = new ArrayList<T>();
    private int size;

    public GenericStack(){
    }

    public int size(){
        return stack.size();
    }

    public T peek(){
        return stack.get(0);
    }

    public void push(T p){
        stack.add(0, p);
    }

    public T pop(){
        T p = stack.get(0);
        stack.remove(0);
        return p;
    }

    public boolean isEmpty() {
        if (size == 0) {
            return true;
        }else{
            return false;
        }
    }

}
