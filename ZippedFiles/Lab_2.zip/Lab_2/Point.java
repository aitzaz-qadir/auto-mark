public class Point<T> {
    
    private T xpos, ypos;

    public Point(T xpos, T ypos){
        this.xpos = xpos;
        this.ypos = ypos;
    }

    public void setX(T xpos){
        this.xpos = xpos;
    }
    public void setY(T ypos){
        this.ypos = ypos;
    }
    public T getX(){
        return xpos;
    }
    public T getY(){
        return ypos;
    }
    public String toString(){
        return ("XPOS: " + xpos + " YPOS: " + ypos);
    }

}
