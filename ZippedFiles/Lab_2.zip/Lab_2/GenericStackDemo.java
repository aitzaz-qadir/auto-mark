import java.util.*;
public class GenericStackDemo{
    public static void main(String[] args){
 
        GenericStack<String> stack1 = new GenericStack<String>();
        GenericStack<Integer> stack2 = new GenericStack<Integer>();

        Scanner sc = new Scanner(System.in);
        int x = 0;

        while(x==0){
            String next = sc.next();
            if(next.equals("quit")){
                x = 1;
            }else{
                stack1.push(next);
            }
        }
        while(x==1){
            int nextInt = sc.nextInt();
            if(nextInt == -1){
                x = 2;
        }else{
                stack2.push(nextInt);
            }
        }

        int sz1 = stack1.size();
        int sz2 = stack2.size();

        System.out.println("String Stack Contents:");
        for(int i = 0; i<sz1; i++){
            System.out.println(stack1.pop());
        }
        System.out.println("Integer Stack Contents:");
        for(int i = 0; i<sz2; i++){
            System.out.println(stack2.pop());
        }
        sc.close();
 }
}