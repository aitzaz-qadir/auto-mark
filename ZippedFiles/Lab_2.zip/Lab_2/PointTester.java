import java.util.*;
public class PointTester {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter integer coordinates x and y: ");
        int xpos = sc.nextInt();
        int ypos = sc.nextInt();
        Point<Integer> point1 = new Point<Integer>(xpos, ypos);

        System.out.println("Enter double coordinates x and y: ");
        double xposD = sc.nextDouble();
        double yposD = sc.nextDouble();
        Point<Double> point2 = new Point<Double>(xposD, yposD);

        System.out.println("Enter String coordinate x and y: ");
        String xposS = sc.next();
        String yposS = sc.next();
        Point<String> point3 = new Point<String>(xposS, yposS);

        System.out.println(point1.toString());
        System.out.println(point2.toString());
        System.out.println(point3.toString());

        sc.close();
    }   
}
